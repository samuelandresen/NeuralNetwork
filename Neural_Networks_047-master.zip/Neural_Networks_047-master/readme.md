## Instructions
***

1. **To test the neural network mini library, run the following command:** <br> 

```
python3 part1_nn_lib.py
```

<br>
 <br>  

2. **To train the neural network, run the following command:** <br>

```
python3 part2_house_value_regression.py
```

<br>
 <br> 
